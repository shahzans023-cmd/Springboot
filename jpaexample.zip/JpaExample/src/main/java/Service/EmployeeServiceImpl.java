package Service;

import Modal.Employee;
import Repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;


@Service
public class EmployeeServiceImpl implements EmployeeService{
    final
    EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {

        this.employeeRepository = employeeRepository;
    }

    @Override
    public ArrayList<Employee>findAllEmployee(){

        return (ArrayList<Employee>) employeeRepository.findAll();
    }

    @Override
    public Employee findAllEmployeeByID(long id){
        Optional<Employee> o=employeeRepository.findById(id);
        return o.orElse(null);
    }

    @Override
    public void addEmployee(Employee employee){
        employeeRepository.save(employee);

    }

    public Employee updateEmployee(long id,Employee employeeDetails) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);

        if (optionalEmployee.isPresent()) {
            Employee existingEmployee = optionalEmployee.get();
            existingEmployee.setName(employeeDetails.getName());
            existingEmployee.setCity(employeeDetails.getCity());

            return employeeRepository.save(existingEmployee);
        }
        return null;
    }


    @Override
    public void deleteAllData() {
        employeeRepository.deleteAll();

    }

    @Override
    public void deleteEmployeeById(long id){
        employeeRepository.deleteById(id);

    }


}
