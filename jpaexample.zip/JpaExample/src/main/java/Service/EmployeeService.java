package Service;
import java.util.ArrayList;
import Modal.Employee;
public interface EmployeeService {
    ArrayList<Employee> findAllEmployee();

    Employee findAllEmployeeByID(long id);

    void addEmployee(Employee employee);

    void deleteAllData();

    Employee updateEmployee(long id, Employee employee);

    void deleteEmployeeById(long id);
}