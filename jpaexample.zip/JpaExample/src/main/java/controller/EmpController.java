package controller;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import Modal.Employee;
import Service.EmployeeServiceImpl;

@RestController
public class EmpController {

    @Autowired
    EmployeeServiceImpl empServiceImpl;

    @PostMapping("/")
    public void add(@org.springframework.web.bind.annotation.RequestBody Employee employee) {
        empServiceImpl.addEmployee(employee);
    }

    @GetMapping("/findall")
    public ArrayList<Employee> getAllEmployee() {
        return empServiceImpl.findAllEmployee();
    }

    @GetMapping("/findbyid/{id}")
    public Employee getEmployeeUsingId(@PathVariable long id) {
        return empServiceImpl.findAllEmployeeByID(id);
    }

    @PutMapping("/update/{id}")
    public Employee updateEmployee(@PathVariable long id, @RequestBody Employee employee) {
        return empServiceImpl.updateEmployee(id, employee);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteEmployeeById(@PathVariable long id){
        empServiceImpl.deleteEmployeeById(id);

    }

    @DeleteMapping("/delete")
    public void delete() {
        empServiceImpl.deleteAllData();
    }
}
