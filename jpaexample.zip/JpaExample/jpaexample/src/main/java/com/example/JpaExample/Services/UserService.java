
 package com.example.JpaExample.Services;

import java.util.List;

import com.example.JpaExample.Enities.User;

public interface UserService {

    public List<User> getUsers();
    
    public User getUser(long id);

    public User addUser(User user);

    public User updateUser(User user);

    public User deleteUser(Long id);

    }
