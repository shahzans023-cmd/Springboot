package com.example.JpaExample.DAO;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.JpaExample.Enities.User;

public interface UserRepository extends MongoRepository<User, String> {
}
