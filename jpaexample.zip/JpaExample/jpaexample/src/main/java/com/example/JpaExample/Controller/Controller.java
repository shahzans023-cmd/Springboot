package com.example.JpaExample.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.JpaExample.Enities.User;
import com.example.JpaExample.Services.UserService;


@RestController 
public class Controller {
    
    
    private final UserService userservice;

    public Controller(UserService userservice) {
        this.userservice = userservice;
    }

    @GetMapping("/home")
	public String getHome() {
		return "this is home page";
	}   
    @GetMapping("/Users")
    public List<User> getUsers() {
        return  this.userservice.getUsers();
    }
    @GetMapping("/Users/{id}")
    public User getUser(@PathVariable String id){
        return this.userservice.getUser(Long.parseLong(id));
    }

    @PostMapping("/Users")
    public User addUser(@RequestBody User user){

        return this.userservice.addUser(user);
    }

    @PutMapping("/Users")
    public User updateUser(@RequestBody User user){

        return this.userservice.updateUser(user);
    }

    @DeleteMapping("/Users/{id}")
    public User deleteUser(@PathVariable Long id) {
        return this.userservice.deleteUser(id);
    }


}
