package com.example.JpaExample.Services;

import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.example.JpaExample.Enities.User;

@Service 
public class UserSerImpl implements UserService{
    
    private final List<User> list = new ArrayList<>();

    public UserSerImpl() {

    }

    @Override 
    public List<User> getUsers(){
        return null;
    }

    @Override 
    public  User getUser(long id){
        
        User u=null;
        for (User user:list){

            if(user.getId().equals(String.valueOf(id))){
                u=user;
                break;
            }
        }

        return u;
    }

    @Override
    public User addUser(User user) {
        list.add(user);
        return user;
    }

    @Override
    public User updateUser(User user) {
        list.add(user);
        return null;
    }

    @Override
    public User deleteUser(Long id) {
        if (id == null) {
            return null;
        }

        for (int i = 0; i < list.size(); i++) {
            User user = list.get(i);
            if (String.valueOf(id).equals(user.getId())) {
                return list.remove(i);
            }
        }
        return null;
    }

    

    
}
